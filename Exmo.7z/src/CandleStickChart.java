import Methods.Ticker;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.xy.DefaultHighLowDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class CandleStickChart extends ApplicationFrame {

    private TimeSeries series;
    public Ticker ticker=new Ticker();


    private ArrayList Dataset=new ArrayList();


        public void getDataset(String pair){
            try {
                ticker.Ticker();
            } catch (Exception e) {
                e.printStackTrace();
            }

            Dataset.addAll(ticker.getDataset(pair));
    }

    public CandleStickChart(String titel) {
        super(titel);

        final DefaultHighLowDataset dataset = createDataset();
        final JFreeChart chart = createChart(dataset);
        final ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(600, 350));
        setContentPane(chartPanel);
    }

    private DefaultHighLowDataset createDataset() {
    getDataset("XRP_USD");
        int serice = 15;

        Date[] date = new Date[serice];
        double[] high = new double[serice];
        double[] low = new double[serice];
        double[] open = new double[serice];
        double[] close = new double[serice];
        double[] volume = new double[serice];

        date[0] = (Date) Dataset.get(8);
        high[0] = Double.parseDouble((String) Dataset.get(0));
        low[0] =  Double.parseDouble((String) Dataset.get(1));
        open[0] =  Double.parseDouble((String) Dataset.get(0))-0.1;
        close[0] =  Double.parseDouble((String) Dataset.get(1))-0.1;
        volume[0] =  Double.parseDouble((String) Dataset.get(3));



        DefaultHighLowDataset data = new DefaultHighLowDataset("", date, high, low, open, close, volume);
        return data;
    }

    private Date createData(int year, int month, int date) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, date);
        return calendar.getTime();
    }

    private JFreeChart createChart(final
                                   DefaultHighLowDataset dataset) {
        final JFreeChart chart = ChartFactory.createCandlestickChart(
                "Candlestick Demo", "Time", "Price", dataset, false);
        return chart;
    }

    public static void main(String args[]) {
        CandleStickChart chart = new CandleStickChart("Candle Stick Chart");
        chart.pack();
        RefineryUtilities.centerFrameOnScreen(chart);
        chart.setVisible(true);
    }
}