import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JPanel;


import Methods.Ticker;
import Methods.Trades;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.DefaultHighLowDataset;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

/**
 * A demonstration application showing a time series chart where you can dynamically add
 * (random) data by clicking on a button.
 *
 */
public class DynamicDataDemo extends ApplicationFrame implements ActionListener {

    /** The time series data. */
    private TimeSeries series;
    public Ticker ticker=new Ticker();

    /** The most recent value added. */
   // private double lastValue = 100.0;
    private ArrayList<Double> arrayPrice=new ArrayList<Double>();
    private ArrayList<Double> arrayTime=new ArrayList<Double>();
    private ArrayList Dataset=new ArrayList();





public void getPairs(){

    Trades trades =new Trades();
    try {
        trades.Trades("XRP_USD");
    } catch (Exception e1) {
        e1.printStackTrace();
    }

   // System.out.println(trades.getArray());
    arrayPrice.addAll(trades.getArrayPrice());
    arrayTime.addAll(trades.getArrTime());
}

public ArrayList getDataset(String pair){

   return ticker.getDataset(pair);
}

    private JFreeChart createChart(final DefaultHighLowDataset dataset) {
        final JFreeChart chart = ChartFactory.createCandlestickChart(
                "Candlestick Demo", "Time", "Price", dataset, false);
        return chart;
    }
    /**
     * Constructs a new demonstration application.
     *
     * @param title  the frame title.
     */
    public DynamicDataDemo(final String title) {



        super(title);
        //this.series = new TimeSeries("Random Data", Millisecond.class);

       /* final TimeSeriesCollection dataset = new TimeSeriesCollection(this.series);
        final JFreeChart chart = createChart(dataset);*/

        final DefaultHighLowDataset dataset = createDataset();
        final JFreeChart chart = createChart(dataset);

        final ChartPanel chartPanel = new ChartPanel(chart);
        final JButton button = new JButton("Add New Data Item");
        button.setActionCommand("ADD_DATA");
        button.addActionListener(this);

        final JPanel content = new JPanel(new BorderLayout());
        content.add(chartPanel);
        content.add(button, BorderLayout.SOUTH);
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
        setContentPane(content);




    }
    private DefaultHighLowDataset createDataset() {

       Dataset.addAll(getDataset("XRP_USD")); // high,  low,  --avg,  vol, --String vol_curr, --String last_trade,  buy_price,  sell_price, updated
       // double serice=arrayTime.get(0);
/*        Date   date = (Date) Dataset.get(8);
        double[] high = (double) Dataset.get(0);
        double[] low = (double) Dataset.get(1);
        double[] open = (double) Dataset.get(0)-0.1;
        double[] close = (double) Dataset.get(1)-0.1;
        double[] volume = (double) Dataset.get(3);*/

        int serice =1;

        Date[] date = new Date[serice];
        double[] high = new double[serice];
        double[] low = new double[serice];
        double[] open = new double[serice];
        double[] close = new double[serice];
        double[] volume = new double[serice];

        date[0] = (Date) Dataset.get(8);
        high[0] = (double) Dataset.get(0);
        low[0] = (double) Dataset.get(1);
        open[0] = (double) Dataset.get(0)-0.1;
        close[0] = (double) Dataset.get(1)-0.1;
        volume[0] = (double) Dataset.get(3);

        DefaultHighLowDataset data = new DefaultHighLowDataset("", date, high, low, open, close, volume);
        return data;
    }

    /**
     * Creates a sample chart.
     *
     * @param dataset  the dataset.
     *
     * @return A sample chart.
     */
/*    private JFreeChart createChart(final XYDataset dataset) {
        final JFreeChart result = ChartFactory.createCandlestickChart("Candle","Time","Value", (OHLCDataset) dataset,true);
        final XYPlot plot = result.getXYPlot();
        ValueAxis axis = plot.getDomainAxis();
        axis.setAutoRange(true);
        axis.setFixedAutoRange(60000.0);  // 60 seconds
        axis = plot.getRangeAxis();
        axis.setRange(1.6, 1.8);
        return result;
    }*/

    // ****************************************************************************
    // * JFREECHART DEVELOPER GUIDE                                               *
    // * The JFreeChart Developer Guide, written by David Gilbert, is available   *
    // * to purchase from Object Refinery Limited:                                *
    // *                                                                          *
    // * http://www.object-refinery.com/jfreechart/guide.html                     *
    // *                                                                          *
    // * Sales are used to provide funding for the JFreeChart project - please    *
    // * support us so that we can continue developing free software.             *
    // ****************************************************************************


    /**
     * Handles a click on the button by adding new (random) data.
     *
     * @param e  the action event.
     */
    public void actionPerformed(final ActionEvent e) {
        if (e.getActionCommand().equals("ADD_DATA")) {


           /* System.out.println(array);
            final double factor = 0.90 + 0.2 * Math.random();
            this.lastValue = this.lastValue * factor;
            final Millisecond now = new Millisecond();
            System.out.println("Now = " + now.toString());
            this.series.add(new Millisecond(), this.lastValue);
*/
         //   Iterator iterator=array.iterator();


            getPairs();
            double Price;
            double Time = 0.0;


            for (int i = 0; i < arrayPrice.size(); i++) {
               if (i==0){
                   Price=arrayPrice.get(0);
                   Time=arrayTime.get(0);
                   i++;
                   System.out.println(" 0 - "+Price);
               }
               else  Price=arrayPrice.get(i);
                this.series.addOrUpdate(new Millisecond(), Price);
                System.out.println(" 1 - "+Price);



            }
        }
    }

    /**
     * Starting point for the demonstration application.
     *
     * @param args  ignored.
     */
    public static void main(final String[] args) {

        final DynamicDataDemo demo = new DynamicDataDemo("Dynamic Data Demo");
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);

    }

}
