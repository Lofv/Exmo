import Methods.Ticker;
import Methods.Trades;

public class Main {

    public static void main(String[] args) throws Exception {

        String pair="BTC_USD";


        Exmo e = new Exmo("your_key","your_secret");
       /* String result = e.Request("user_info", null);
        System.out.println(result);
        String result2 = e.Request("user_cancelled_orders", new HashMap<String, String>() {{
            put("limit", "2");
            put("offset", "0");
        }});

        System.out.println(result2);*/

    /*   Exmo1 exmo1=new Exmo1();

        String result3 = exmo1.Request("trades", new HashMap<String, String>() {{
           put("pair", "BTC_USD");
            //put("offset", "0");
        }});*/


     //   System.out.println(result3);

      //  Trades js =new Trades();
      //  js.Trades("XRP_USD");

        Ticker ticker =new Ticker();
        ticker.Ticker();
        ticker.getDataset("XRP_USD");

    }
}
