package Methods;


import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Ticker {

    ArrayList list;
    String surl="https://api.exmo.com/v1/ticker/";
    Map<String, ArrayList> Dataset = new HashMap<String, ArrayList>(){};


    private void setDataset(String pair, ArrayList list) {
        Dataset.put(pair, list);
    }
    private void setList(String high, String low, String avg, String vol, String vol_curr, String last_trade, String buy_price, String sell_price, long updated) {
        list.add(high);
        list.add(low);
        list.add(avg);
        list.add(vol);
        list.add(vol_curr);
        list.add(last_trade);
        list.add(buy_price);
        list.add(sell_price);
        list.add(setDate(updated));

    }
    private String setDate(long sec) {
        Calendar cal = Calendar.getInstance();
        Date time =new Date(sec*1000L); // *1000 получаем миллисекунды
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss z"); // какой формат нужен, выбераем
        sdf.setTimeZone(TimeZone.getTimeZone(cal.getTimeZone().getID())); // если нужно даем таймзон
        String formattedDate = sdf.format(time);

        return formattedDate;

    }


    public ArrayList getDataset(String pair) {
/*
        Iterator itr = Dataset.entrySet().iterator();

        while (itr.hasNext()) {
            Map.Entry entry = (Map.Entry) itr.next();
            //получить ключ
            String key = (String) entry.getKey();
            //получить значение

            if (key.equals(s)) {
                ArrayList value = (ArrayList) entry.getValue();
           for (int i = 0; i < value.size(); i++) {
}*/


           return Dataset.get(pair);

    }
    public ArrayList getList() {
        return list;
    }


    public void Ticker() throws Exception {

            String pair;
            URL url=new URL(surl);
            HttpURLConnection request=(HttpURLConnection)url.openConnection();
            request.connect();



        JSONParser parser = new JSONParser();


        try {

            JSONObject file=(JSONObject) parser.parse(new InputStreamReader((InputStream) request.getContent()));

            Set keys = file.keySet();
            Iterator iterator=keys.iterator();

             while (iterator.hasNext()){
             list= new ArrayList();

              pair= (String) iterator.next();
              JSONObject object= (JSONObject) file.get(pair);


                String high =           (String) object.get("high");
                String low  =           (String) object.get("low");
                String avg  =           (String) object.get("avg");
                String vol  =           (String) object.get("vol");
                String vol_curr   =     (String) object.get("vol_curr");
                String last_trade =     (String) object.get("last_trade");
                String buy_price  =     (String) object.get("buy_price");
                String sell_price =     (String) object.get("sell_price");
                long   updated    =     (long)   object.get("updated");

                //System.out.println("pair = "+ pair);
/*                System.out.println("pair = "+ pair);
                System.out.println();
                System.out.println();
                System.out.println("high = "+ high);
                System.out.println("low = " + low);;
                System.out.println("avg = " + avg);;
                System.out.println("vol = " + vol);
                System.out.println("vol_curr = " + vol_curr);
                System.out.println("last_trade = " + last_trade);
                System.out.println("buy_price = " + buy_price);
                System.out.println("sell_price = " + sell_price);
                System.out.println("updated = " + updated);*/

                 setList (high, low , avg, vol,vol_curr, last_trade, buy_price, sell_price, updated);
                 setDataset(pair,getList());

           }

        } catch (IOException | ParseException ex) {
            Logger.getLogger(Ticker.class.getName())
                    .log(Level.SEVERE, null, ex);
        }

    }





}
