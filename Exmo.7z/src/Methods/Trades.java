package Methods;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class Trades {

    ArrayList arrPrice=new ArrayList<Double>();
    ArrayList arrTime=new ArrayList();



    private String newDate(long sec){
        Calendar cal = Calendar.getInstance();
        Date time =new Date(sec*1000L); // *1000 получаем миллисекунды
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss z"); // какой формат нужен, выбераем
        sdf.setTimeZone(TimeZone.getTimeZone(cal.getTimeZone().getID())); // если нужно даем таймзон
        String formattedDate = sdf.format(time);
        return formattedDate;
    }

    public ArrayList<Double> getArrayPrice (){

        return arrPrice;
}
    public ArrayList getArrTime(){
        return arrTime;
    }


    private void setArrayPrice(String price){

    arrPrice.add(Double.parseDouble(price));


}
    private void setArrayTime (long sec){
        arrTime.add(newDate(sec));
    }

    public void Trades(String pair) throws Exception {


        String surl="https://api.exmo.com/v1/trades/?pair=";

            URL url=new URL(surl+pair);
            HttpURLConnection request=(HttpURLConnection)url.openConnection();
            request.connect();



        JSONParser parser = new JSONParser();


        try {

            JSONObject file=(JSONObject) parser.parse(new InputStreamReader((InputStream) request.getContent()));
            JSONArray jsonarray= (JSONArray) file.get(pair);



            for (int i = jsonarray.size()-1; i >0 ; i--) {
                
                JSONObject object=(JSONObject)jsonarray.get(i);
                
                

                String amount = (String) object.get("amount");
                String quantity = (String) object.get("quantity");
                String price = (String) object.get("price");
                String type = (String) object.get("type");

                long trade_id = (long) object.get("trade_id");
                long date = (long) object.get("date");


              /*  System.out.println();
                System.out.println();
                    System.out.println("amount: " + amount);
                    System.out.println("trade_id: " + trade_id);
                    System.out.println("quantity: " + quantity);
                    System.out.println("price: " + price);
                    System.out.println("type: " + type);
                    System.out.println("date: " + newDate(date));*/

                    setArrayPrice(price);
                    setArrayTime(date);

            }

        } catch (IOException | ParseException ex) {
            Logger.getLogger(Trades.class.getName())
                    .log(Level.SEVERE, null, ex);
        }

    }
}
